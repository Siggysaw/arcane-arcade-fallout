import FalloutZeroItemBase from './itemBase.mjs'

export default class FalloutZeroFeature extends FalloutZeroItemBase {}
